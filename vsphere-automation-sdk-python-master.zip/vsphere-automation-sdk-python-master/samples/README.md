Directory       | Description
----------------| -------------
vSphere         | Samples for vSphere APIs
vmc             | Samples for VMware Cloud on AWS Services (currently in preview)
