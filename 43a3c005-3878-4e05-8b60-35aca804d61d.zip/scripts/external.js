function externalLinks() {  

 if (!document.getElementsByTagName) return;   
 var anchors = document.getElementsByTagName("a");   
 for (var i=0; i<anchors.length; i++) {   
   var anchor = anchors[i];   
   if (anchor.getAttribute("href") &&   
       anchor.getAttribute("rel") == "external")   
     anchor.target = "_blank";   
 }   
}   

window.onload = externalLinks;


function SendFeedback() {
    var loc = location.href;
    
    
    var loc = location.href;
    var subject = "";
    if (this.product.length > 0)
        subject = this.product;
    if (this.vrm.length > 0)
        subject = subject + this.vrm;
    
    if (subject.length > 0)
        subject = " " + subject;
        
    subject = loc + subject;
   
    if (subject.charAt(subject.length-1)==(","))
    {
        subject = subject.substring(0,subject.length-1);
    }
    
    location.href = "mailto:docfeedback@vmware.com?Subject=Topic: " + subject;
}

